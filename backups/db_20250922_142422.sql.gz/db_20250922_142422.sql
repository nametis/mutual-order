--
-- PostgreSQL database dump
--

\restrict bYE9f1lj4EzIdvcQkA2lm13yk5AfLKidpCeinxY82buV6X9AWb65H4d2vNI3uAl

-- Dumped from database version 15.14
-- Dumped by pg_dump version 15.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: chat_read_status; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.chat_read_status (
    id integer NOT NULL,
    user_id integer NOT NULL,
    order_id integer NOT NULL,
    last_read_at timestamp without time zone
);


ALTER TABLE public.chat_read_status OWNER TO postgres;

--
-- Name: chat_read_status_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.chat_read_status_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.chat_read_status_id_seq OWNER TO postgres;

--
-- Name: chat_read_status_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.chat_read_status_id_seq OWNED BY public.chat_read_status.id;


--
-- Name: listing; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.listing (
    id integer NOT NULL,
    discogs_id character varying(20) NOT NULL,
    title character varying(500) NOT NULL,
    price_value double precision NOT NULL,
    currency character varying(5) NOT NULL,
    media_condition character varying(50) NOT NULL,
    sleeve_condition character varying(50) NOT NULL,
    image_url text,
    listing_url text NOT NULL,
    status character varying(50),
    last_checked timestamp without time zone,
    added_at timestamp without time zone,
    user_id integer NOT NULL,
    order_id integer NOT NULL
);


ALTER TABLE public.listing OWNER TO postgres;

--
-- Name: listing_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.listing_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.listing_id_seq OWNER TO postgres;

--
-- Name: listing_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.listing_id_seq OWNED BY public.listing.id;


--
-- Name: order; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."order" (
    id integer NOT NULL,
    seller_name character varying(100) NOT NULL,
    creator_id integer NOT NULL,
    created_at timestamp without time zone,
    status character varying(20),
    status_changed_at timestamp without time zone,
    max_amount double precision,
    deadline timestamp without time zone,
    payment_timing character varying(50),
    seller_shop_url text,
    direct_url text,
    shipping_cost double precision,
    taxes double precision,
    discount double precision,
    user_location character varying(200)
);


ALTER TABLE public."order" OWNER TO postgres;

--
-- Name: order_chat; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.order_chat (
    id integer NOT NULL,
    order_id integer NOT NULL,
    user_id integer NOT NULL,
    message text NOT NULL,
    created_at timestamp without time zone
);


ALTER TABLE public.order_chat OWNER TO postgres;

--
-- Name: order_chat_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.order_chat_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.order_chat_id_seq OWNER TO postgres;

--
-- Name: order_chat_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.order_chat_id_seq OWNED BY public.order_chat.id;


--
-- Name: order_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.order_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.order_id_seq OWNER TO postgres;

--
-- Name: order_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.order_id_seq OWNED BY public."order".id;


--
-- Name: user; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."user" (
    id integer NOT NULL,
    discogs_username character varying(80) NOT NULL,
    discogs_access_token character varying(200) NOT NULL,
    discogs_access_secret character varying(200) NOT NULL,
    mutual_order_username character varying(80),
    profile_completed boolean,
    is_admin boolean,
    created_at timestamp without time zone
);


ALTER TABLE public."user" OWNER TO postgres;

--
-- Name: user_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_id_seq OWNER TO postgres;

--
-- Name: user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.user_id_seq OWNED BY public."user".id;


--
-- Name: user_validation; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_validation (
    id integer NOT NULL,
    user_id integer NOT NULL,
    order_id integer NOT NULL,
    validated boolean,
    validated_at timestamp without time zone
);


ALTER TABLE public.user_validation OWNER TO postgres;

--
-- Name: user_validation_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.user_validation_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_validation_id_seq OWNER TO postgres;

--
-- Name: user_validation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.user_validation_id_seq OWNED BY public.user_validation.id;


--
-- Name: chat_read_status id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.chat_read_status ALTER COLUMN id SET DEFAULT nextval('public.chat_read_status_id_seq'::regclass);


--
-- Name: listing id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.listing ALTER COLUMN id SET DEFAULT nextval('public.listing_id_seq'::regclass);


--
-- Name: order id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."order" ALTER COLUMN id SET DEFAULT nextval('public.order_id_seq'::regclass);


--
-- Name: order_chat id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_chat ALTER COLUMN id SET DEFAULT nextval('public.order_chat_id_seq'::regclass);


--
-- Name: user id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."user" ALTER COLUMN id SET DEFAULT nextval('public.user_id_seq'::regclass);


--
-- Name: user_validation id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_validation ALTER COLUMN id SET DEFAULT nextval('public.user_validation_id_seq'::regclass);


--
-- Data for Name: chat_read_status; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.chat_read_status (id, user_id, order_id, last_read_at) FROM stdin;
\.


--
-- Data for Name: listing; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.listing (id, discogs_id, title, price_value, currency, media_condition, sleeve_condition, image_url, listing_url, status, last_checked, added_at, user_id, order_id) FROM stdin;
6	3825767333	Love In Stereo	5	EUR	Very Good Plus (VG+)	Very Good Plus (VG+)	https://i.discogs.com/MFad9yciHfoZacauFSm4F8LUTx2PN2G9gFTeiXhS1-o/rs:fit/g:sm/q:90/h:601/w:600/czM6Ly9kaXNjb2dz/LWRhdGFiYXNlLWlt/YWdlcy9SLTE3ODg4/NTYtMTQwMzk1NTk2/Ni00MjkyLmpwZWc.jpeg	https://www.discogs.com/sell/item/3825767333	For Sale	2025-09-22 07:47:15.736956	2025-09-22 07:47:15.73697	1	1
7	3825770663	Hit It Up EP	12	EUR	Very Good Plus (VG+)	Very Good Plus (VG+)	https://i.discogs.com/vse7KISZkGYy2kaLOQ2rBfVsd5_SuizsrDcwvQZCKCM/rs:fit/g:sm/q:90/h:600/w:600/czM6Ly9kaXNjb2dz/LWRhdGFiYXNlLWlt/YWdlcy9SLTExMjQ1/LTExNDM2NDg1MjYu/anBlZw.jpeg	https://www.discogs.com/sell/item/3825770663	For Sale	2025-09-22 07:47:27.587256	2025-09-22 07:47:27.587271	1	1
9	3832271810	Blue Pacific	17	EUR	Very Good Plus (VG+)	Very Good Plus (VG+)	https://i.discogs.com/WEU-U4zwmrM3lNnIovtIXUC3L7_mYZh0Cw1kE_-VT18/rs:fit/g:sm/q:90/h:600/w:600/czM6Ly9kaXNjb2dz/LWRhdGFiYXNlLWlt/YWdlcy9SLTM2MjA2/NjItMTM5NjExNDAw/My0zMTQyLmpwZWc.jpeg	https://www.discogs.com/sell/item/3832271810	For Sale	2025-09-22 09:52:40.600679	2025-09-22 09:52:40.600694	1	1
11	3832271924	Bar Lea	12	EUR	Very Good Plus (VG+)	Very Good Plus (VG+)	https://i.discogs.com/oVoxZp8r8ks_aisPvZHkHWZi9Jtvg-MujVqOQTAkW9A/rs:fit/g:sm/q:90/h:563/w:557/czM6Ly9kaXNjb2dz/LWRhdGFiYXNlLWlt/YWdlcy9SLTYxMDQx/MzktMTQxMTE2NDYw/MS05MTY5LmpwZWc.jpeg	https://www.discogs.com/sell/item/3832271924	For Sale	2025-09-22 10:02:27.230987	2025-09-22 10:02:27.231001	1	1
13	1845433144	Ogooué	19.5	EUR	Mint (M)	Mint (M)	https://i.discogs.com/n2dG_Ms13q6OxAU9uL6zvstzeljGxhMt24fPCbmkllo/rs:fit/g:sm/q:90/h:595/w:600/czM6Ly9kaXNjb2dz/LWRhdGFiYXNlLWlt/YWdlcy9SLTE0MDIx/NDc2LTE1Nzg0MDMx/NTAtMjkyNi5qcGVn.jpeg	https://www.discogs.com/sell/item/1845433144	For Sale	2025-09-22 10:44:09.26935	2025-09-22 10:44:09.269363	1	2
\.


--
-- Data for Name: order; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."order" (id, seller_name, creator_id, created_at, status, status_changed_at, max_amount, deadline, payment_timing, seller_shop_url, direct_url, shipping_cost, taxes, discount, user_location) FROM stdin;
1	Energy.ctrl.center	1	2025-09-22 06:40:54.354429	closed	2025-09-22 10:27:22.779392	260	2025-10-03 00:00:00	avant la commande	\N	\N	0	0	0	\N
2	Bassleer	1	2025-09-22 10:38:17.272916	building	\N	300	2025-10-03 00:00:00	avant la commande	\N	\N	0	0	0	\N
\.


--
-- Data for Name: order_chat; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.order_chat (id, order_id, user_id, message, created_at) FROM stdin;
1	1	1	bonjour	2025-09-22 09:46:23.051388
2	1	1	bjr	2025-09-22 09:47:15.425132
3	1	1	test	2025-09-22 09:52:28.944461
4	1	1	fgfgfgfg	2025-09-22 09:52:55.880133
5	1	1	test	2025-09-22 09:59:14.89557
6	1	1	ls	2025-09-22 10:00:31.544325
7	1	1	test	2025-09-22 10:02:18.049008
\.


--
-- Data for Name: user; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."user" (id, discogs_username, discogs_access_token, discogs_access_secret, mutual_order_username, profile_completed, is_admin, created_at) FROM stdin;
1	vinc305	IdRVQRucRreTGcsVfWEOWAofsKUZJirpmpbOxmXG	GyYFjtwFlITrrwLaYOwcCqDsFzqBlOAECpKHwciN	Vincent	t	t	2025-09-22 06:40:31.660004
\.


--
-- Data for Name: user_validation; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_validation (id, user_id, order_id, validated, validated_at) FROM stdin;
\.


--
-- Name: chat_read_status_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.chat_read_status_id_seq', 1, false);


--
-- Name: listing_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.listing_id_seq', 13, true);


--
-- Name: order_chat_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.order_chat_id_seq', 7, true);


--
-- Name: order_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.order_id_seq', 2, true);


--
-- Name: user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.user_id_seq', 1, true);


--
-- Name: user_validation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.user_validation_id_seq', 1, false);


--
-- Name: chat_read_status chat_read_status_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.chat_read_status
    ADD CONSTRAINT chat_read_status_pkey PRIMARY KEY (id);


--
-- Name: listing listing_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.listing
    ADD CONSTRAINT listing_pkey PRIMARY KEY (id);


--
-- Name: order_chat order_chat_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_chat
    ADD CONSTRAINT order_chat_pkey PRIMARY KEY (id);


--
-- Name: order order_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."order"
    ADD CONSTRAINT order_pkey PRIMARY KEY (id);


--
-- Name: listing unique_listing_per_order; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.listing
    ADD CONSTRAINT unique_listing_per_order UNIQUE (discogs_id, order_id);


--
-- Name: chat_read_status unique_user_order_read_status; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.chat_read_status
    ADD CONSTRAINT unique_user_order_read_status UNIQUE (user_id, order_id);


--
-- Name: user_validation unique_user_order_validation; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_validation
    ADD CONSTRAINT unique_user_order_validation UNIQUE (user_id, order_id);


--
-- Name: user user_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_pkey PRIMARY KEY (id);


--
-- Name: user_validation user_validation_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_validation
    ADD CONSTRAINT user_validation_pkey PRIMARY KEY (id);


--
-- Name: ix_listing_discogs_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_listing_discogs_id ON public.listing USING btree (discogs_id);


--
-- Name: ix_listing_order_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_listing_order_id ON public.listing USING btree (order_id);


--
-- Name: ix_listing_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_listing_status ON public.listing USING btree (status);


--
-- Name: ix_listing_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_listing_user_id ON public.listing USING btree (user_id);


--
-- Name: ix_order_chat_order_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_order_chat_order_id ON public.order_chat USING btree (order_id);


--
-- Name: ix_order_chat_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_order_chat_user_id ON public.order_chat USING btree (user_id);


--
-- Name: ix_order_creator_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_order_creator_id ON public."order" USING btree (creator_id);


--
-- Name: ix_order_seller_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_order_seller_name ON public."order" USING btree (seller_name);


--
-- Name: ix_order_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_order_status ON public."order" USING btree (status);


--
-- Name: ix_user_discogs_username; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_user_discogs_username ON public."user" USING btree (discogs_username);


--
-- Name: ix_user_mutual_order_username; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_user_mutual_order_username ON public."user" USING btree (mutual_order_username);


--
-- Name: chat_read_status chat_read_status_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.chat_read_status
    ADD CONSTRAINT chat_read_status_order_id_fkey FOREIGN KEY (order_id) REFERENCES public."order"(id) ON DELETE CASCADE;


--
-- Name: chat_read_status chat_read_status_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.chat_read_status
    ADD CONSTRAINT chat_read_status_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."user"(id);


--
-- Name: listing listing_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.listing
    ADD CONSTRAINT listing_order_id_fkey FOREIGN KEY (order_id) REFERENCES public."order"(id);


--
-- Name: listing listing_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.listing
    ADD CONSTRAINT listing_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."user"(id);


--
-- Name: order_chat order_chat_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_chat
    ADD CONSTRAINT order_chat_order_id_fkey FOREIGN KEY (order_id) REFERENCES public."order"(id) ON DELETE CASCADE;


--
-- Name: order_chat order_chat_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_chat
    ADD CONSTRAINT order_chat_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."user"(id);


--
-- Name: order order_creator_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."order"
    ADD CONSTRAINT order_creator_id_fkey FOREIGN KEY (creator_id) REFERENCES public."user"(id);


--
-- Name: user_validation user_validation_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_validation
    ADD CONSTRAINT user_validation_order_id_fkey FOREIGN KEY (order_id) REFERENCES public."order"(id);


--
-- Name: user_validation user_validation_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_validation
    ADD CONSTRAINT user_validation_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."user"(id);


--
-- PostgreSQL database dump complete
--

\unrestrict bYE9f1lj4EzIdvcQkA2lm13yk5AfLKidpCeinxY82buV6X9AWb65H4d2vNI3uAl

